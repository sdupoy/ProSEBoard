package fr.eseo.ld.proseboard.models;

import static org.junit.Assert.*;

import org.junit.Test;

public class ExpertiseAreaTest {

	@Test
	public void testConstructor() {
		ExpertiseArea expAr = new ExpertiseArea();
		assertNotNull(expAr);
	}
	
	@Test
	public void testGetIdExp() {
		ExpertiseArea expAr = new ExpertiseArea();
		assertNotNull(expAr);
		expAr.setIdExp(123L);
		assertEquals(123L,expAr.getIdExp(),0.1);
	}
	
	@Test
	public void testGetNameExp() {
		ExpertiseArea expAr = new ExpertiseArea();
		assertNotNull(expAr);
		expAr.setNameExp("Test");
		assertEquals("Test",expAr.getNameExp());
	}

}
