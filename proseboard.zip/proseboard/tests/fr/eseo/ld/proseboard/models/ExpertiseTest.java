package fr.eseo.ld.proseboard.models;

import static org.junit.Assert.*;

import org.junit.Test;

public class ExpertiseTest {

	@Test
	public void testEmptyConstructor() {
		Expertise exp = new Expertise();
		assertNotNull(exp);
	}
	
	@Test
	public void testGetIdExp(){
		Expertise exp = new Expertise();
		assertNotNull(exp);
		exp.setIdExp(234L);
		assertEquals(exp.getIdExp(), 234L, 0.1);
	}

	@Test
	public void testGetIdUser(){
		Expertise exp = new Expertise();
		assertNotNull(exp);
		exp.setIdUser(234L);
		assertEquals(exp.getIdUser(), 234L, 0.1);
	}
	
	@Test
	public void testGetName() {
		Expertise exp = new Expertise();
		assertNotNull(exp);
		exp.setName("EssaiNom");
		assertEquals(exp.getName(), "EssaiNom");
	}
}
