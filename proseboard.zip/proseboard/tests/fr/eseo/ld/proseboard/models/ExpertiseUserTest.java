package fr.eseo.ld.proseboard.models;

import static org.junit.Assert.*;

import org.junit.Test;

public class ExpertiseUserTest {

	@Test
	public void testConstructor() {
		ExpertiseUser expUsr = new ExpertiseUser();
		assertNotNull(expUsr);
	}
	
	@Test
	public void testGetIdExp() {
		ExpertiseUser expUsr = new ExpertiseUser();
		assertNotNull(expUsr);
		expUsr.setIdExpertise(123L);
		assertEquals(123L,expUsr.getIdExpertise(),0.1);
	}

	@Test
	public void testGetIdUser() {
		ExpertiseUser expUsr = new ExpertiseUser();
		assertNotNull(expUsr);
		expUsr.setIdUser(123L);
		assertEquals(123L,expUsr.getIdUser(),0.1);
	}
}
