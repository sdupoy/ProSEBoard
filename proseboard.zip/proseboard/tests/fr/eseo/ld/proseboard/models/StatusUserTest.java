package fr.eseo.ld.proseboard.models;
import static org.junit.Assert.*;

import org.junit.Test;


public class StatusUserTest {
	
	
	@Test
	public void testEmptyConstructeur() {
		StatusUser statusUser = new StatusUser();
		assertNotNull(statusUser);
	}
	
	
	@Test
	public final void testGetIdSession(){
		StatusUser statusUser = new StatusUser();
		statusUser.setIdSession(1L);
		assertEquals(statusUser.getIdSession(),1L,0.1);
	}
	
	@Test
	public final void testGetIdStatus(){
		StatusUser statusUser = new StatusUser();
		statusUser.setIdStatus(1L);
		assertEquals(statusUser.getIdStatus(),1L,0.1);
	}
	
	@Test
	public final void testGetIdUser(){
		StatusUser statusUser = new StatusUser();
		statusUser.setIdUser(1L);
		assertEquals(statusUser.getIdUser(),1L,0.1);
	}

}
