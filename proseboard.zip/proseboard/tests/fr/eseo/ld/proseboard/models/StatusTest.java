package fr.eseo.ld.proseboard.models;

import static org.junit.Assert.*;

import org.junit.Test;

public class StatusTest {

	@Test
	public void testGetId() {
		Status s = new Status();
		Long i = (long) 267678374;
		s.setId(i);
		assertEquals(i,s.getId());
	}
	
	@Test
	public void testGetName() {
		Status s = new Status();
		String name = "admin";
		s.setName(name);
		assertEquals(name,s.getName());
	}

	@Test
	public void testGetIdSession() {
		Status s = new Status();
		Long i = (long) 267678374;
		s.setIdSession(i);
		assertEquals(i,s.getIdSession());
	}
}
