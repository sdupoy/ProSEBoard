package fr.eseo.ld.proseboard.models;

public class TrainingUser {
	
	
	private Long idTraining;
	private Long idUser;
	private boolean isAbsent;
	
	public TrainingUser(){
		
	}

	public Long getIdTraining() {
		return idTraining;
	}

	public void setIdTraining(Long idTraining) {
		this.idTraining = idTraining;
	}

	public Long getIdUser() {
		return idUser;
	}

	public void setIdUser(Long idUser) {
		this.idUser = idUser;
	}

	public boolean getIsAbsent() {
		return isAbsent;
	}

	public void setIsAbsent(boolean isAbsent) {
		this.isAbsent = isAbsent;
	}
	
	
	
	

}
