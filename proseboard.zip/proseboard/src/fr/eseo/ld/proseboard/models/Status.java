package fr.eseo.ld.proseboard.models;

import java.io.Serializable;

public class Status implements Serializable{

    private static final long serialVersionUID = 1L;

    private Long      id;
    private String    name;
    private Long idSession;
    private Session session;

    public Long getId() {
        return id;
    }

    public void setId( Long id ) {
        this.id = id;
    }

    public void setName( String name ) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public Long getIdSession() {
        return idSession;
    }

    public void setIdSession(Long idSession) {
        this.idSession = idSession;
    }

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }
    
    
}
