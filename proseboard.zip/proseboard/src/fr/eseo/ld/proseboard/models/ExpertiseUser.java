package fr.eseo.ld.proseboard.models;

public class ExpertiseUser {
	private Long idExpertise;
	private Long idUser;
	
	
	public ExpertiseUser(){
		
	}




	public Long getIdExpertise() {
		return idExpertise;
	}




	public void setIdExpertise(Long idExpertise) {
		this.idExpertise = idExpertise;
	}




	public Long getIdUser() {
		return idUser;
	}


	public void setIdUser(Long idUser) {
		this.idUser = idUser;
	}
	
	
	
}
