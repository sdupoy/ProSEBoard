package fr.eseo.ld.proseboard.models;

public class StatusUser {
	private Long idUser;
	private Long idStatus;
	private Long idSession;
	
	
	public StatusUser(){
		
	}


	public Long getIdUser() {
		return idUser;
	}


	public void setIdUser(Long idUser) {
		this.idUser = idUser;
	}


	public Long getIdStatus() {
		return idStatus;
	}


	public void setIdStatus(Long idStatus) {
		this.idStatus = idStatus;
	}


	public Long getIdSession() {
		return idSession;
	}


	public void setIdSession(Long idSession) {
		this.idSession = idSession;
	}
	
	
}
