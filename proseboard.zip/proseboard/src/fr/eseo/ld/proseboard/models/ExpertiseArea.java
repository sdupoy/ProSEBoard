package fr.eseo.ld.proseboard.models;



public class ExpertiseArea {
	
	
	private Long idExp;
	private String nameExp;
	
	
	public ExpertiseArea(){
		
	}


	public Long getIdExp() {
		return idExp;
	}


	public void setIdExp(Long idExp) {
		this.idExp = idExp;
	}


	public String getNameExp() {
		return nameExp;
	}


	public void setNameExp(String nameExp) {
		this.nameExp = nameExp;
	}
	
	
	
	
	
}
