package fr.eseo.ld.proseboard.models;

public class TeamUser {
	
	private Long idUser;
	private Long idTeam;

	public TeamUser(){
		
	}
	
	public TeamUser(Long idUser, Long idTeam){
		this.idUser = idUser;
		this.idTeam = idTeam;
	}

	public Long getIdUser() {
		return idUser;
	}

	public void setIdUser(Long idUser) {
		this.idUser = idUser;
	}

	public Long getIdTeam() {
		return idTeam;
	}

	public void setIdTeam(Long idTeam) {
		this.idTeam = idTeam;
	}
	
	
}
