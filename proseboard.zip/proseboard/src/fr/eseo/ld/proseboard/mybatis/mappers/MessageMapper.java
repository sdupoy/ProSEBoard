package fr.eseo.ld.proseboard.mybatis.mappers;

import java.util.List;

import fr.eseo.ld.proseboard.models.Message;

public interface MessageMapper {
	public List<Message> getAll(int id);
	public void insert(Message message);
 	public List<Message> getAllEmetter(int id);
 	public void supprimerReception(int id);
 	public void supprimerEnvoi(int id);
 	public void supprimerBDD();
 	public void readMessage(int id);
 	public int count(int id);
}
