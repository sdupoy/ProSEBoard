package fr.eseo.ld.proseboard.mybatis.mappers;

import java.util.List;

import fr.eseo.ld.proseboard.models.AccountHistory;

public interface AccountHistoryMapper {

	public List<AccountHistory> getByIdHistory(Long idAccount);
}
