package fr.eseo.ld.proseboard.mybatis.mappers;

import java.util.List;

import fr.eseo.ld.proseboard.models.StatusUser;

public interface StatusUserMapper {
	public void deleteBySessionId(Long idSession);
	public List<StatusUser> getByIdTeacher();
}
