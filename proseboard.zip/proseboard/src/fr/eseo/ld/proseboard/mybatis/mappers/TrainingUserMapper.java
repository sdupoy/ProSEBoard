package fr.eseo.ld.proseboard.mybatis.mappers;

import java.util.List;

import fr.eseo.ld.proseboard.models.TrainingUser;

public interface TrainingUserMapper {
	public List<TrainingUser> getAllByIdUser(Long id);
}
